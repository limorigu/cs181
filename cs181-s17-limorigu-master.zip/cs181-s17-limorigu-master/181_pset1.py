
# coding: utf-8

# In[119]:

#####################
# CS 181, Spring 2016
# Homework 1, Problem 3
#
##################

import csv
import numpy as np
import matplotlib.pyplot as plt

csv_filename = 'congress-ages.csv'
times  = []
ages = []

with open(csv_filename, 'r') as csv_fh:

    # Parse as a CSV file.
    reader = csv.reader(csv_fh)

    # Skip the header line.
    next(reader, None)

    # Loop over the file.
    for row in reader:

        # Store the data.
        times.append(float(row[0]))
        ages.append(float(row[1]))

# Turn the data into numpy arrays.
times  = np.array(times)
ages = np.array(ages)

# Plot the data.
# Just a figure and one subplot
plt.plot(times, ages, 'o')
plt.xlabel("Congress age (nth Congress)")
plt.ylabel("Average age")
plt.show()

# Create the simplest basis, with just the time and an offset.
X = np.vstack((np.ones(times.shape), times)).T

# Nothing fancy for outputs.
Y = ages

# Find the regression weights using the Moore-Penrose pseudoinverse.
w = np.linalg.solve(np.dot(X.T, X) , np.dot(X.T, Y))


# Compute the regression line on a grid of inputs.
# DO NOT CHANGE grid_times!!!!!
grid_times = np.linspace(75, 120, 200)

grid_X = np.vstack((np.ones(grid_times.shape), grid_times))

grid_Yhat = np.dot(grid_X.T, w)

# Plot the data and the regression line.
plt.plot(times, ages, 'o', grid_times, grid_Yhat, '-')
plt.xlabel("Congress age (nth Congress)")
plt.ylabel("Average age")

plt.show()


# In[126]:

def loss_fun(Y, Y_hat):
    return np.dot((Y-Y_hat).T, (Y-Y_hat))


# In[153]:

#phi_1 case 

times_1 = []

#generate new times, based on basis function
#as a setup for a new X matrix
for i in range(1,7):
    times_1.append([x**i for x in times])
    
X_1 = np.vstack((np.ones(times.shape), times_1)).T

w_1 = np.linalg.solve(np.dot(X_1.T, X_1) , np.dot(X_1.T, Y))

# generate Y hat prediction for original data
Yhat_1 = np.dot(X_1, w_1)

    
grid_1 = []

# geneate new grid_times and Yhat prediction, which correspond to the new X matrix
# based on the basis function
for i in range(1,7):
    grid_1.append([x**i for x in grid_times])
    
grid_X_1 = np.vstack((np.ones(grid_times.shape), grid_1))

grid_Yhat_1  = np.dot(grid_X_1.T, w_1)

# plot all new components
plt.plot(times, ages, 'o', grid_times, grid_Yhat_1, '-')
plt.show()
print("Loss function for basis func 1", loss_fun(Y, Yhat_1))


# In[152]:

#phi_2 case 
times_2 = []

#generate new times, based on basis function
#as a setup for a new X matrix
for i in range(1,5):
    times_2.append([x**i for x in times])
    
X_2 = np.vstack((np.ones(times.shape), times_2)).T

w_2 = np.linalg.solve(np.dot(X_2.T, X_2) , np.dot(X_2.T, Y))
    
grid_2 = []

# generate Y hat prediction for original data
Yhat_2 = np.dot(X_2, w_2)


# geneate new grid_times and Yhat prediction, which correspond to the new X matrix
# based on the basis function
for i in range(1,5):
    grid_2.append([x**i for x in grid_times])
    
grid_X_2 = np.vstack((np.ones(grid_times.shape), grid_2))

grid_Yhat_2 = np.dot(grid_X_2.T, w_2)

# plot all new components
plt.plot(times, ages, 'o', grid_times, grid_Yhat_2, '-')
plt.show()
print("Loss function for basis func 2", loss_fun(Y, Yhat_2))


# In[151]:

#phi_3 case 
times_3 = []

#generate new times, based on basis function
#as a setup for a new X matrix
for i in range(1,7):
    times_3.append([np.sin(x/i) for x in times])
    
X_3 = np.vstack((np.ones(times.shape), times_3)).T

w_3 = np.linalg.solve(np.dot(X_3.T, X_3) , np.dot(X_3.T, Y))

# generate Y hat prediction for original data
Yhat_3 = np.dot(X_3, w_3)
    
grid_3 = []


# geneate new grid_times and Yhat prediction, which correspond to the new X matrix
# based on the basis function
for i in range(1,7):
    grid_3.append([np.sin(x/i) for x in grid_times])
    
grid_X_3 = np.vstack((np.ones(grid_times.shape), grid_3))

grid_Yhat_3 = np.dot(grid_X_3.T, w_3)

# plot all new components
plt.plot(times, ages, 'o', grid_times, grid_Yhat_3, '-')
plt.show()
print("Loss function for basis func 3", loss_fun(Y, Yhat_3))


# In[150]:

#phi_4 case 
times_4 = []

#generate new times, based on basis function
#as a setup for a new X matrix
for i in range(1,11):
    times_4.append([np.sin(x/i) for x in times])
    
X_4 = np.vstack((np.ones(times.shape), times_4)).T

w_4 = np.linalg.solve(np.dot(X_4.T, X_4) , np.dot(X_4.T, Y))
    
grid_4 = []

# generate Y hat prediction for original data

Yhat_4 = np.dot(X_4, w_4)


# geneate new grid_times, which correspond to the new X matrix
# based on the basis function

for i in range(1,11):
    grid_4.append([np.sin(x/i) for x in grid_times])
    
grid_X_4 = np.vstack((np.ones(grid_times.shape), grid_4))

grid_Yhat_4 = np.dot(grid_X_4.T, w_4)

# plot all new components
plt.plot(times, ages, 'o', grid_times, grid_Yhat_4, '-')
plt.ylim(ymin=49, ymax = 60)
plt.show()
print("Loss function for basis func 4", loss_fun(Y, Yhat_4))


# In[149]:

#phi_5 case 
times_5 = []

#generate new times, based on basis function
#as a setup for a new X matrix
for i in range(1,23):
    times_5.append([np.sin(x/i) for x in times])
    
X_5 = np.vstack((np.ones(times.shape), times_5)).T

w_5 = np.linalg.solve(np.dot(X_5.T, X_5) , np.dot(X_5.T, Y))
    
grid_5 = []

# generate Y hat prediction for original data
Yhat_5 = np.dot(X_5, w_5)

# geneate new grid_times, which correspond to the new X matrix
# based on the basis function
for i in range(1,23):
    grid_5.append([np.sin(x/i) for x in grid_times])
    
grid_X_5 = np.vstack((np.ones(grid_times.shape), grid_5))

grid_Yhat_5 = np.dot(grid_X_5.T, w_5)

# plot all new components
plt.plot(times, ages, 'o', grid_times, grid_Yhat_5, '-')
plt.ylim(ymin=49, ymax = 60)
plt.show()
print("Loss function for basis func 5", loss_fun(Y, Yhat_5))


# In[ ]:



